#include <stdio.h>

int main()
{
    long int n;
    scanf("%d",&n);
    printf("%d",n);
    return 0;
}
